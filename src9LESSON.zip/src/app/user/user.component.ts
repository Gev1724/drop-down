import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  inputName: string = '';
  inputAge: number;
  users = [
    {
      name: 'hayk',
      age: 20
    },
    {
      name: 'davit',
      age: 21
    },
    {
      name: 'gevorg',
      age: 22
    },
    {
      name: 'arman',
      age: 23
    }
  ];

  

  constructor() { }

  ngOnInit() {
  }

  addUser(){
    this.users.push({
      name: this.inputName,
      age: this.inputAge
    });
    this.inputName = '';
    this.inputAge = null;
  }

}
