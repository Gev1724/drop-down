import { Injectable } from '@angular/core';
import { Console3Service } from './console3.service';

@Injectable({
  providedIn: 'root'
})
export class Console1Service {

  str : string = 'hayk';

  constructor(private cs3 : Console3Service) {}

  log(){
    console.log('This is Console1Service');
    console.log( this.cs3.x );

  }

}
