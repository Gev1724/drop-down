import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {HomeComponent} from './home/home.component';
import {CarComponent} from './car/car.component';
import {CarsComponent} from './cars/cars.component';
import {NoteFoundComponent} from './note-found/note-found.component';

const appRoutes: Routes = [
  {path: '', component: HomeComponent},
  {path: 'cars', component: CarsComponent},
  {path: 'cars/:id/:name', component: CarComponent},
  {path: 'note-found', component: NoteFoundComponent},
  {path: '**', redirectTo: 'note-found'}
];


@NgModule({
 imports: [ RouterModule.forRoot(appRoutes)],
 exports: [RouterModule]
})
export class AppRoutesModule { }
