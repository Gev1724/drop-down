import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import {LexusComponent} from './lexus/lexus.component';
import { BmwComponent } from './bmw/bmw.component';
import { CarsComponent } from './cars/cars.component';
import { UserComponent } from './user/user.component';
import { DoctorComponent } from './doctor/doctor.component';
import { BackgroundDirective } from './directives/background.directive';
import { HoverDirective } from './directives/hover.directive';
import { PowPipe } from './pipes/pow.pipe';
import { CarsFilterPipe } from './pipes/cars-filter.pipe';
import { PipeFilterComponent } from './pipe-filter/pipe-filter.component';
import { RformComponent } from './rform/rform.component';
import {CarsService} from './cars.service';

import { HttpClientModule } from '@angular/common/http';
import { CarComponent } from './car/car.component';
import { HomeComponent } from './home/home.component';
import {AppRoutesModule} from './app-routes.module';
import { NoteFoundComponent } from './note-found/note-found.component';


@NgModule({
  declarations: [
    AppComponent,
    LexusComponent,
    BmwComponent,
    CarsComponent,
    UserComponent,
    DoctorComponent,
    BackgroundDirective,
    HoverDirective,
    PowPipe,
    CarsFilterPipe,
    PipeFilterComponent,
    RformComponent,
    CarComponent,
    HomeComponent,
    NoteFoundComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    AppRoutesModule
  ],
  providers: [CarsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
