import { Directive, OnInit, ElementRef, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appBackground]'
})
export class BackgroundDirective implements OnInit{

  constructor(private element: ElementRef, private renderer: Renderer2) {
    console.log('constructor');
  }
  ngOnInit(){
    //this.element.nativeElement.style.backgroundColor = 'red';
    const {nativeElement} = this.element;
    this.renderer.setStyle(nativeElement, 'background-color', 'blue');
  }


}
