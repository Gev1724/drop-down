import { Directive, HostBinding, HostListener, Input, OnInit } from '@angular/core';

@Directive({
  selector: '[appHover]'
})
export class HoverDirective implements OnInit{


  @HostBinding('style.backgroundColor') background: string;
  @Input() defaultColor: string;

  constructor() {
    //this.element.nativeElement.style.backgroundColor = 'red';
  }

  ngOnInit(){
    this.background = this.defaultColor;
  }

  @HostListener('mouseenter')mouseenter(){
    this.background = this.defaultColor;
  }
  @HostListener('mouseleave')mouseleave(){
    this.background = 'pink';
  }

}
