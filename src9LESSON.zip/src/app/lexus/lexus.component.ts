import { Component } from '@angular/core';

@Component({
  selector: 'app-lexus',
  templateUrl: './lexus.component.html',
  styleUrls: ['./lexus.component.css']
})
export class LexusComponent {

  private model: string = 'RX350';
  private color: string = 'black';
  private pubYear: number = 2008;
  private price: number = 14200;
  private myText: string = 'HELLO';
  private inputText: string = '';
  private inputText2: string = '';

  flag: boolean = true;

  constructor(){
      setTimeout( ()=>{
        this.flag = false;
      } ,4000);
  }

  getPrice() : number{
    return this.price;
  }

  myClick(){
    this.myText = 'HELLO HAYK';
  }


  inputFunc(event){
    this.inputText = event.target.value;
    console.log(event);
  }

  inputFunc2(input2){
    this.inputText2 = input2.value;
  }

}
