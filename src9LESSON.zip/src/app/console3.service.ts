export class Console3Service{

  users = [
    {
      name: 'haykabelyan',
      age: 31
    },
    {
      name: 'haykabelyan',
      age: 32
    },
    {
      name: 'haykabelyan',
      age: 22
    }
  ];

  x: number = 10;
}
