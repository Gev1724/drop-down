import { Component, OnInit } from '@angular/core';
import {FormGroup, FormControl, Validators} from '@angular/forms';

@Component({
  selector: 'app-rform',
  templateUrl: './rform.component.html',
  styleUrls: ['./rform.component.css']
})
export class RformComponent implements OnInit {

  form: FormGroup;
  x: number = 5;

  constructor() { }

  ngOnInit() {
    this.form = new FormGroup({

      user: new FormGroup({
        email: new FormControl('', [Validators.required, Validators.email], [this.checkFormEmail]),
        pass: new FormControl('', [Validators.required, this.checkforLength.bind(this)]),
      }),
      select: new FormControl('1'),
      answer: new FormControl('no')
    });
  }

  onSubmit(){
    console.log(this.form);
  }

  checkforLength(control: FormControl){
    if(control.value.length < this.x){
      return {'lengthError': true};
    }
    return null;
  }

  checkFormEmail(control: FormControl) : Promise<any> {
    return new Promise((resolve, reject)=>{
      setTimeout(()=>{
        if(control.value == 'hayk@gmail.com'){ resolve({'emailIsUsed': true});}
        else{resolve(null);}
      },3000);
    });
  }

}
