import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'carsFilter',
  pure: false
})
export class CarsFilterPipe implements PipeTransform {

  transform(carList: any, searchCar: any) {
    console.log("++++++++++++");
     if(carList.length ===0 || searchCar === ''){
      return carList;
    }
    return carList.filter((car) => car.name.toLowerCase().indexOf(searchCar) !== -1);
  }

}
