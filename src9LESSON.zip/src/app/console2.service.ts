export class Console2Service{
  
  cars = [
    {
      name: 'opel'
    },
    {
      name: 'mers'
    },
    {
      nmae: 'bmw'
    }
  ];
  
  log(str){
    console.log(str);
  }
  
  addNewCar(car){
    this.cars.push({
      name: car
    });
  }
  
  
}
