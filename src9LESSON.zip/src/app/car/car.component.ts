import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, Params} from '@angular/router';


@Component({
  selector: 'app-car',
  templateUrl: './car.component.html',
  styleUrls: ['./car.component.css']
})
export class CarComponent implements OnInit {
  id;
  name;
  constructor(private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    // this.id = +this.activatedRout.snapshot.params['id'];
    // this.name = this.activatedRoute.snapshot.params['name'];
    this.activatedRoute.params.subscribe((params: Params) => {
      this.id = + params['id'];
      this.name = params['name'];
    });
  }
}
