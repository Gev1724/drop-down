export interface ICar{
  id: number;
  name: string;
  color: string;
}



