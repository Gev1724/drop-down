import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bmw',
  templateUrl: './bmw.component.html',
  styleUrls: ['./bmw.component.css']
})
export class BmwComponent implements OnInit {



  iText1:string = '';
  iText2:string = '';
  flag: boolean = true;

  constructor() { }

  ngOnInit() {
  }

  inputText1(input1){
    this.iText1 = input1.value;
  }
  inputText2(input2){
    this.iText2 = input2.value;
  }

  onClick(){
    console.log(this.iText1);
    console.log(this.iText2);
  }


  addCar(){
    this.flag = false;
  }

}
