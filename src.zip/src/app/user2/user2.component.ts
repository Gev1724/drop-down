import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user2',
  templateUrl: './user2.component.html',
  styleUrls: ['./user2.component.css']
})
export class User2Component implements OnInit {
  inputName = '';
  inputAge = null;
  users = [
    {
      name: 'Gev',
      age: 20
    },
    {
      name: 'Hayk',
      age: 25
    },
    {
      name: 'Davit',
      age: 30
    }
  ];
  developers = [
    {
      name: 'Gev',
      job: 'javaScript'
    },
    {
      name: 'Hay',
      job: 'Java'
    },
    {
      name: 'Dav',
      job: 'HTML CSS'
    }
    ]
  constructor() { }

  ngOnInit() {
  }
  addUser() {
    this.users.push({
      name: this.inputName,
      age: this.inputAge
    });
    this.inputName = '';
    this.inputAge = null;
  }
}
