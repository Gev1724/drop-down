export class Console3Service {
  x: number = 10;
}
