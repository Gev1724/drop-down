import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-swich-case',
  templateUrl: './swich-case.component.html',
  styleUrls: ['./swich-case.component.css']
})
export class SwichCaseComponent implements OnInit {
  pipeNum:number = 5;
  nums = [1, 2, 3, 4, 5];
  current:number = 1;
  constructor() { }

  ngOnInit() {
  }
  onClick(item) {
    this.current = item;
  }
}
