import {Component, OnInit, ɵbypassSanitizationTrustResourceUrl} from '@angular/core';
import {st} from '@angular/core/src/render3';

@Component({
  selector: 'app-bmw',
  templateUrl: './bmw.component.html',
  styleUrls: ['./bmw.component.css']
})
export class BmwComponent implements OnInit {
  private loginInput: string = 'Login';
  private passwordInput: string = 'Password';
  private input1Text: string = '';
  private input2Text: string = '';
  private flag:boolean = true;
  constructor() { }

  ngOnInit() {
  }
  input1Func(event){
    return this.input1Text = event.target.value;
  }
  input2Func(event){
    return this.input2Text = event.target.value;
  }

  btnClick() {
    setTimeout( () => {
      this.loginInput = this.input1Text;
      this.passwordInput = this.input2Text;
    },4000);
  }
  addCar() {
    this.flag = false;
  }

}
