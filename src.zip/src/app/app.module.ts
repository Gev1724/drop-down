import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import {LexusComponent} from './lexus/lexus.component';
import { BmwComponent } from './bmw/bmw.component';
import { UserComponent } from './user/user.component';
import {User1Component} from './user1/user1.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { CarsComponent } from './cars/cars.component';
import { CarComponent } from './car/car.component';
import {HttpClientModule} from '@angular/common/http';
import { MyCompComponent } from './my-comp/my-comp.component';
import { MembersComponent } from './members/members.component';
import { ProductComponent } from './product/product.component';
import { User2Component } from './user2/user2.component';
import { DoctorComponent } from './doctor/doctor.component';
import { DeveloperComponent } from './developer/developer.component';
import { BackgroundDirective } from './directives/background.directive';
import { HoverDirective } from './directives/hover.directive';
import { ParrentComponent } from './parrent/parrent.component';
import {FirstChildComponent} from './parrent/first-child/first-child.component';
import {SecondChildComponent} from './parrent/second-child/second-child.component';
import { SwichCaseComponent } from './swich-case/swich-case.component';
import { PowPipe } from './pipes/pow.pipe';
import { CarsFilterPipe } from './pipes/cars-filter.pipe';
import { PipeFilterComponent } from './pipe-filter/pipe-filter.component';
import { NumbersFilterPipe } from './pipes/numbers-filter.pipe';
import { FirstServiceComponent } from './first-service/first-service.component';
import {Console1Service} from './console1.service';
import {Console3Service} from './console3.service';
import { RformComponent } from './rform/rform.component';
import { HomeworkRformComponent } from './homework-rform/homework-rform.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { registerLocaleData } from '@angular/common';
import { NgZorroAntdModule, NZ_I18N, en_US } from 'ng-zorro-antd';
import en from '@angular/common/locales/en';
import { HttpClientComponent } from './http-client/http-client.component';
import {CarService} from './car.service';

registerLocaleData(en);


@NgModule({
  declarations: [
    AppComponent,
    LexusComponent,
    BmwComponent,
    UserComponent,
    User1Component,
    CarsComponent,
    CarComponent,
    MyCompComponent,
    MembersComponent,
    ProductComponent,
    User2Component,
    DoctorComponent,
    DeveloperComponent,
    BackgroundDirective,
    HoverDirective,
    ParrentComponent,
    FirstChildComponent,
    SecondChildComponent,
    SwichCaseComponent,
    PowPipe,
    CarsFilterPipe,
    PipeFilterComponent,
    NumbersFilterPipe,
    FirstServiceComponent,
    RformComponent,
    HomeworkRformComponent,
    HttpClientComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    NgZorroAntdModule,
  ],
  providers: [
    Console1Service,
    Console3Service,
    CarService,
    { provide: NZ_I18N, useValue: en_US },
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
