import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {reject} from 'q';

@Component({
  selector: 'app-rform',
  templateUrl: './rform.component.html',
  styleUrls: ['./rform.component.css']
})
export class RformComponent implements OnInit {
  form: FormGroup;
  x: number = 5;

  constructor() { }

  ngOnInit() {
    this.form = new FormGroup({
      user: new FormGroup({
        email: new FormControl('', [Validators.required, Validators.email], [this.checkFormEmail]),
        pass: new FormControl('', [Validators.required, this.checkForLength.bind(this)]),
      }),
      select: new FormControl('2'),
      answer: new FormControl('no'),
    });
  }
  onSubmit () {
    console.log(this.form);
  }
  checkForLength(control: FormControl) {
    if (control.value.length <= this.x) {
      return {'lengthError': true};
    } else {
      return null;
    }
  }
  checkFormEmail(control: FormControl): Promise<any> {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (control.value === 'gev.gabrielyan@mail.ru') {
          resolve( {'emailIsUsed': true});
        } else {
          resolve (null);
        }
      }, 2000);
    });
  }
}
