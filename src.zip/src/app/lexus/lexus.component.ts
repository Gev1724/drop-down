import { Component } from '@angular/core';

@Component({
  selector: 'app-lexus',
  templateUrl: './lexus.component.html',
  styleUrls: ['./lexus.component.css']
})
export class LexusComponent {
  private model:string = 'RX350';
  private color: string = 'blak';
  private pubYear: number = 2008;
  private price: number = 14000;
  private flag: boolean = true;
  private myText: string = 'HELLO';
  private inputMyText: string = '';
  private inputMyText1: string = '';

  constructor() {
    setTimeout( () => {
      this.flag = false;
    }, 4000);
  }

  getPrice(): number {
    return this.price;
  }
  myClick() {
    this.myText = 'HELLO GEV';
  }
  inputFunc(event) {
    this.inputMyText =  event.target.value;
  }
  inputFunc2(input2) {
    this.inputMyText1 = input2.value;
  }
}
