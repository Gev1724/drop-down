import { Component, OnInit } from '@angular/core';
import { Console2Service } from '../console2.service';
import {Console1Service} from '../console1.service';

@Component({
  selector: 'app-first-service',
  templateUrl: './first-service.component.html',
  styleUrls: ['./first-service.component.css'],
  providers: [Console2Service]
})
export class FirstServiceComponent implements OnInit {
  cars = [];
  inputValue = '';
  constructor(private cs: Console2Service, private cs1: Console1Service) {
    // const cs = new Console2Service();
  }
  inputText(event) {
    this.inputValue = event.target.value;
  }
  ngOnInit() {
    this.cars = this.cs.cars;
    this.cs1.log();
  }
  text() {
    this.cs.addNewCar(this.inputValue);
    this.inputValue = '';
    console.log(this.cars);
  }

}
