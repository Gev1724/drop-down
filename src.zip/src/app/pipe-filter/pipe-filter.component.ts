import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipe-filter',
  templateUrl: './pipe-filter.component.html',
  styleUrls: ['./pipe-filter.component.css']
})
export class PipeFilterComponent implements OnInit {
  searchCar = '';
  cars = [
    {name: 'opel'},
    {name: 'lexus'},
    {name: 'bmw'}
  ];
  constructor() { }

  ngOnInit() {
  }

}
