export class Console2Service {
  cars = [
    {
      name: 'opel'
    },
    {
      name: 'bmw'
    },
    {
      name: 'lexus'
    }
  ];
  addNewCar(car) {
    this.cars.push({
      name: car
    });
  }
  log(str) {
    console.log(str);
    console.log(this.cars);
  }
}
