import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cars',
  templateUrl: './cars.component.html',
  styleUrls: ['./cars.component.css']
})
export class CarsComponent implements OnInit {
  private inputText: string = '';
  private name: string = 'Gev';
  private pi: number = 3.14765;
  cars = ['bmw', 'opel', 'merc', 'lexus'];
  constructor() {}

  ngOnInit() {
  }
  addCar() {
    this.cars.push(this.inputText);
    this.inputText = '';
  }
  getBool() {
    return true;
  }
}
