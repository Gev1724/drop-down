import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-first-child',
  templateUrl: './first-child.component.html',
  styleUrls: ['./first-child.component.css']
})
export class FirstChildComponent implements OnInit {
  private inputValue;
  private text;
  constructor() { }

  ngOnInit() {}
  btn() {
    setTimeout(() => {
      this.text = this.inputValue;
    }, 1000);
  }
  inputText(event) {
    this.inputValue =  event.target.valueAsNumber;
  }

}
