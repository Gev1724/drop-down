import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parrent',
  templateUrl: './parrent.component.html',
  styleUrls: ['./parrent.component.css']
})
export class ParrentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
