import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homework-rform',
  templateUrl: './homework-rform.component.html',
  styleUrls: ['./homework-rform.component.css']
})
export class HomeworkRformComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
