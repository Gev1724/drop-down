import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FormsService {
  user = [];
  constructor() { }
  addNewUser(u) {
    this.user.push(u);
    console.log(this.user)
  }
}
