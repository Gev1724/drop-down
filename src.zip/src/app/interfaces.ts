import {s} from '@angular/core/src/render3';

export interface ICar {
  id: number;
  name: string;
  color: string;
}
