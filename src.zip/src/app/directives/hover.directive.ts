import {Directive, HostBinding, HostListener, Input, OnInit} from '@angular/core';

@Directive({
  selector: '[appHover]'
})
export class HoverDirective implements OnInit {
  @Input() defoultColor: string;
  @HostBinding('style.backgroundColor') background: string;
  constructor() { }
  ngOnInit() {
    this.background = this.defoultColor;
  }
  @HostListener('mouseenter') mouseenter() {
    this.background = 'pink';
  }
  @HostListener('mouseleave') mouseleave() {
    this.background = 'orange';
  }
}
