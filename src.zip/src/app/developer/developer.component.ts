import {Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'app-developer',
  templateUrl: './developer.component.html',
  styleUrls: ['./developer.component.css']
})
export class DeveloperComponent implements OnInit {
  @Input('user') developer;
  constructor() { }

  ngOnInit() {
  }

}
