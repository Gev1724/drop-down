import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'pow'
})
export class PowPipe implements PipeTransform {

  transform(value: any, args: any, str: any) {
    console.log(args)
    return str + Math.pow(value, args);
  }

}
