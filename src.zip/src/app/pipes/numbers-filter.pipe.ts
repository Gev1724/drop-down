import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'numbersFilter'
})
export class NumbersFilterPipe implements PipeTransform {

  transform(value) {
    let n = 0;
    let j = 0;
    console.log(value);
    if (value !== undefined && value !== null) {
      for (let i = 1; i <= value; i++) {
        if (i % 2 === 0) {
          n++;
        } else {
          j++;
        }
      }
      return n + ' is even ' + j + ' is odd.';
    }
  }
}
