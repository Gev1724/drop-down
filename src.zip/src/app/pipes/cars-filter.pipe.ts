import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'carsFilter',
})
export class CarsFilterPipe implements PipeTransform {
  transform(carList: any, searchCar: any) {
    console.log(carList);
    if (carList.length === 0 || searchCar === '' ) {
      return carList;
    }
    return carList.filter((car) => car.name.toLowerCase().indexOf(searchCar) !== -1);
  }

}
