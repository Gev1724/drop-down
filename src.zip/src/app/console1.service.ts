import { Injectable } from '@angular/core';
import { Console3Service } from './console3.service';

@Injectable({
  providedIn: 'root'
})
export class Console1Service {

  constructor(private cs3: Console3Service) {
  }
  log() {
    console.log('++++++++++');
    console.log(this.cs3.x);
  }
}
