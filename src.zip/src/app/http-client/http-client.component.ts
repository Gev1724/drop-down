import { Component, OnInit } from '@angular/core';
import { ICar } from '../interfaces';
import {CarService} from '../car.service';

@Component({
  selector: 'app-http-client',
  templateUrl: './http-client.component.html',
  styleUrls: ['./http-client.component.css']
})
export class HttpClientComponent implements OnInit {
  cars: ICar[];
  constructor(private carServise: CarService) { }

  ngOnInit() {
    return this.carServise.getCar().subscribe((cars: ICar[]) =>{
      this.cars = cars.results;
      console.log(this.cars);
    });
  }

}
